#include "llvm/IR/Constants.h"
#include "llvm/IR/Instructions.h"
#include "llvm/IR/Module.h"
#include "llvm/IR/Type.h"

using namespace llvm;

namespace cot {

struct HelloLLVM : public ModulePass {
public:
	static char ID;

public:
	HelloLLVM() : ModulePass(ID) { }

public:
	// This member function must implement the code of your pass.
	virtual bool runOnModule(Module &Mod) override;

	// The getAnalysisUsage allows to tell LLVM pass manager which analysis are
	// used by the pass. It is also used to declare which analysis are preserved
	// by the pass.
	virtual void getAnalysisUsage(AnalysisUsage &AU) const override;

	virtual StringRef getPassName() const override {
		return "Hello llvm";
	}

private:
	// Helper functions:
	// - Fetch or create a printf declaration
	// - Fetch or create a HelloWorld function which calls printf
	// - Fetch or create a main function which calls HelloWorld

	Function &GetPrintf(Module &Mod);
	Function &GetHelloWorld(Module &Mod, bool &Built);
	void AddMain(Module &Mod, Function &HelloFun, bool &Modified);

};

char HelloLLVM::ID = 0;

bool HelloLLVM::runOnModule(Module &Mod) {
	return true;
}

void HelloLLVM::getAnalysisUsage(AnalysisUsage &AU) const {
	// This pass does no require any analysis.
	// This pass potentially invalidates all analysis.
	// The default behaviour is to invalidate all, so no code is required here.
	return;
}

Function &HelloLLVM::GetHelloWorld(Module &Mod, bool &Modified) {
	// TODO implement
	return nullptr;
}

void HelloLLVM::AddMain(Module &Mod,
												Function &HelloFun,
												bool &Modified) {
	// TODO implement
	return;
}

Function &HelloLLVM::GetPrintf(Module &Mod) {
	// TODO implement
	return nullptr;
}

// Pass registration: advise the PassManager about our pass
static RegisterPass<HelloLLVM> X(
			"Hello", 						// command line switch
			"Insert an Hello World Function",	// Human readable pass description
			true,								// True: Can modify CFG      | False: Only reads CFG
			true 								// True: Transformation Pass | False: Analysis Pass
			);

} /* cot */
