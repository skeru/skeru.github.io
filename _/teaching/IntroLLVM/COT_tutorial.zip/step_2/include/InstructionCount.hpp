#ifndef INSTRUCTION_COUNT_HPP
#define INSTRUCTION_COUNT_HPP

#include "llvm/Pass.h"
#include "llvm/IR/Function.h"
#include "llvm/Support/raw_ostream.h"

namespace cot {
struct InstructionCount : public llvm::FunctionPass {

public:
	static char ID; // mandatory static pass ID

	// default constructor must call parent constructor with ID
	// Additionally, it initializes private member counter to 0
	InstructionCount() : llvm::FunctionPass(ID), counter(0) {}

	// This member function will be invoked on every function found on the module
	// currently considered by the compiler.
	virtual bool runOnFunction(llvm::Function &F) override;

	// Declaration of analysis required by this pass
	// Delcaration of which analysis are preserved and invalidated by this pass.
	virtual void getAnalysisUsage(llvm::AnalysisUsage &AU) const override;

public:
	// allows to access information computed by this analysis.
	// By putting the implementation of the method in the header file
	// we allow its call to be inlined
	unsigned getInstructionCount() const { return counter; }

private:
	unsigned counter;

}; // end of struct InstructionCount
}

#endif /* end of include guard: INSTRUCTION_COUNT_HPP */
