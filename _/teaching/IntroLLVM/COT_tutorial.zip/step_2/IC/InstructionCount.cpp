#include "InstructionCount.hpp"

using namespace cot;

// static initialization
char InstructionCount::ID = 0;

bool InstructionCount::runOnFunction(llvm::Function &Fun) {
	return false; // True: we modified Fun | False: we did not modify Fun
}

// Pass registration: advise the PassManager about our pass
static RegisterPass<InstructionCount> X(
			"IC", 							// command line switch
			"Instruction Count",// Human readable pass description
			false,							// True: Can modify CFG      | False: Only reads CFG
			false 							// True: Transformation Pass | False: Analysis Pass
			);
