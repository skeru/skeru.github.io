#ifndef Function_ERASER_HPP
#define Function_ERASER_HPP

#include "llvm/Pass.h"
#include "llvm/IR/Function.h"
#include "llvm/Support/raw_ostream.h"

namespace cot {

// Function Eraser erase the body of a Function whenever
// the number of instructions is below a given threshold
struct FunctionEraser : public llvm::FunctionPass {

public:
	static char ID; // mandatory static pass ID

	// default constructor must call parent constructor with ID
	FunctionEraser() : llvm::FunctionPass(ID) {}

	// This member function will be invoked on every function found on the module
	// currently considered by the compiler.
	virtual bool runOnFunction(llvm::Function &F) override;

	// Declaration of analysis required by this pass
	// Delcaration of which analysis are preserved and invalidated by this pass.
	virtual void getAnalysisUsage(llvm::AnalysisUsage &AU) const override;

	// In case anyone in the framework asks, not really mandatory
	virtual llvm::StringRef getPassName() const override {
		return "Function Eraser";
	}

}; // end of struct FunctionEraser
}

#endif /* end of include guard: Function_ERASER_HPP */
