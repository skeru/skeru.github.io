#include "FunctionEraser.hpp"
#include "InstructionCount.hpp"
#include "llvm/ADT/Statistic.h"
#include "llvm/Support/CommandLine.h"

using namespace cot;
using namespace llvm;

// static initialization
char InstructionCount::ID = 0;

bool FunctionEraser::runOnFunction(Function &Fun) {
	return false; // True: we modified Fun | False: we did not modify Fun
}

void FunctionEraser::getAnalysisUsage(AnalysisUsage &AU) const {
	AU.addRequired<InstructionCount>();
}

// Pass registration: advise the PassManager about our pass
static RegisterPass<FunctionEraser> X(
			"FE", 							// command line switch
			"Function Eraser",	// Human readable pass description
			false,							// True: Can modify CFG      | False: Only reads CFG
			true 								// True: Transformation Pass | False: Analysis Pass
			);
