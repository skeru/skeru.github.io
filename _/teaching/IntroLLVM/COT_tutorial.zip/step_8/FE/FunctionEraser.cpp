#define DEBUG_TYPE "FunctionEraser"

#include "FunctionEraser.hpp"
#include "InstructionCount.hpp"
#include "llvm/ADT/Statistic.h"
#include "llvm/Support/CommandLine.h"

using namespace cot;
using namespace llvm;

// LLVM command line library allows straightforward declaration of command line
// options. Here we are declaring 'EraseThreshold' as a command line argument of
// type unsigned. It can be set using the '-erase-threshold' command line
// option and its default value is the greatest 'unsigned'.
cl::opt<unsigned> EraseThreshold(
									"erase-threshold",
									cl::init(std::numeric_limits<unsigned>::max()),
									cl::Hidden,
									cl::desc("Erasing threshold in number of instructions"));

// Statistics are global counters you can use to collect information about the
// behavior of your pass during compilation.
// Automatically declares a static global unsigned variable ErasedFunctions
STATISTIC(ErasedFunctions, "Number of functions erased");

// static initialization
char InstructionCount::ID = 0;

bool FunctionEraser::runOnFunction(Function &Fun) {
	// Get the analysis we need. Please notice that we are not giving any argument
	// to 'getAnalysis'. This is the correct way for requesting analysis from
	// 'llvm::FunctionPass'. If you need to get analysis information from a
	// 'llvm::ModulePass', then you have to give the Function you want to analyze
	// as 'getAnalysis' argument.
	InstructionCount &ICount = getAnalysis<InstructionCount>();

	if(ICount.getInstructionCount() < EraseThreshold)
		return false;	// True: we modified Fun | False: we did not modify Fun

	// Apply the transformation by erasing function body.
	Fun.deleteBody();

	// Update pass statistics.
	++ErasedFunctions;

	return true;	// True: we modified Fun | False: we did not modify Fun
}

void FunctionEraser::getAnalysisUsage(AnalysisUsage &AU) const {
	AU.addRequired<InstructionCount>();
}

// Pass registration: advise the PassManager about our pass
static RegisterPass<FunctionEraser> X(
			"FE", 							// command line switch
			"Function Eraser",	// Human readable pass description
			false,							// True: Can modify CFG      | False: Only reads CFG
			true 								// True: Transformation Pass | False: Analysis Pass
			);

#undef DEBUG_TYPE
