#include "InstructionCount.hpp"

using namespace cot;
using namespace llvm;

// static initialization
char InstructionCount::ID = 0;

bool InstructionCount::runOnFunction(Function &Fun) {
	for (const auto & BB : Fun) {
		counter += BB.size();
	}
	return false; // True: we modified Fun | False: we did not modify Fun
}

void InstructionCount::getAnalysisUsage(AnalysisUsage &AU) const {
	// No analysis required.
	// This is an analysis, nothing is modified, so other analysis are preserved.
	AU.setPreservesAll();
}

void InstructionCount::print(raw_ostream &OS, const Module *Mod) const {
	if(!Mod)
		return;
	OS << "  Instruction count: " << counter << "\n";
}

// Pass registration: advise the PassManager about our pass
static RegisterPass<InstructionCount> X(
			"IC", 							// command line switch
			"Instruction Count",// Human readable pass description
			false,							// True: Can modify CFG      | False: Only reads CFG
			false 							// True: Transformation Pass | False: Analysis Pass
			);
