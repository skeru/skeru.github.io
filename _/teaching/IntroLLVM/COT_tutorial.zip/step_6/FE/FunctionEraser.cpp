#define DEBUG_TYPE "FunctionEraser"

#include "FunctionEraser.hpp"
#include "InstructionCount.hpp"
#include "llvm/ADT/Statistic.h"
#include "llvm/Support/CommandLine.h"

using namespace cot;
using namespace llvm;

// Statistics are global counters you can use to collect information about the
// behavior of your pass during compilation.
// Automatically declares a static global unsigned variable ErasedFunctions
STATISTIC(ErasedFunctions, "Number of functions erased");

// static initialization
char InstructionCount::ID = 0;

bool FunctionEraser::runOnFunction(Function &Fun) {
	return false; // True: we modified Fun | False: we did not modify Fun
}

void FunctionEraser::getAnalysisUsage(AnalysisUsage &AU) const {
	AU.addRequired<InstructionCount>();
}

// Pass registration: advise the PassManager about our pass
static RegisterPass<FunctionEraser> X(
			"FE", 							// command line switch
			"Function Eraser",	// Human readable pass description
			false,							// True: Can modify CFG      | False: Only reads CFG
			true 								// True: Transformation Pass | False: Analysis Pass
			);

#undef DEBUG_TYPE
